pi = 3.14
r = 10
H = 50

V = r * r * pi * H
print(V)
